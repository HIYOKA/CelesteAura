# Scripts
Any extra (funky) Javascript that you want to load along with your
theme should be located here. This could be:

* Special configuration for elFinder under your theme
* Extra JavaScript libraries that your theme depends on
* Javascript hacks to the elFinder markup after the file browser has loaded (not recommended)
