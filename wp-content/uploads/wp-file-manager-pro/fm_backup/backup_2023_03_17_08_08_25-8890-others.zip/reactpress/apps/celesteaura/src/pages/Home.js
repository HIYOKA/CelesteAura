import React from "react";

function Home() {
  return <h1>Home 화면 입니다. </h1>;
}

export default Home;