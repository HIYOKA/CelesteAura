import Contact from "./hiyoka/Contact";

function App2() {
  return (
    <div className="App2">
      <Contact />
    </div>
  );
}

export default App2;
