import React from "react";

function Button() {
  return <button>버튼</button>;
}

export default Button;
