import Home from "./hiyoka/Home";
import Posts from "./hiyoka/Posts";

function App() {
  return (
    <div className="App">
      <Home />
      <Posts />
    </div>
  );
}

export default App;