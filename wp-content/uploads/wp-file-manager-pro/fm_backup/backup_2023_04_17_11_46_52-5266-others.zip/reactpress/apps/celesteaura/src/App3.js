import Button from "./hiyoka/Button";

function App3() {
  return (
    <div className="App3">
      <Button />
    </div>
  );
}

export default App3;
