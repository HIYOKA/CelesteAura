//import Home from "./hiyoka/Home";
//import Posts from "./hiyoka/Posts";
//import Media from "./hiyoka/Media";
import Test from "./hiyoka/Test";
//import Text from "./hiyoka/Text";

function App() {
  return (
    <div className="App">
      <Test />
    </div>
  );
}

export default App;