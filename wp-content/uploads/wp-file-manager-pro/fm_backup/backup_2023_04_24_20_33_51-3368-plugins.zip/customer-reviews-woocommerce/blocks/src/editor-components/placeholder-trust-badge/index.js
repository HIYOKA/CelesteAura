const PlaceholderTrustBadge = () => {
	return (
		<div class="cr-placeholder-tb">
			<div class="cr-placeholder-tb-fr"></div>
			<div class="cr-placeholder-tb-sr"></div>
		</div>
	);
};

export default PlaceholderTrustBadge;
