<?php
namespace ivole\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}
